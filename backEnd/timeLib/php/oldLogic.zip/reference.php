<?php

// Date & Time References

//$months = [
//            'jan' => 'january',
//            'feb' => 'february',
//            'mar' => 'march',
//            'apr' => 'april',
//            'may' => 'may',
//            'jun' => 'june',
//            'jul' => 'july',
//            'aug' => 'august',
//            'sep' => 'september',
//            'oct' => 'october',
//            'nov' => 'november',
//            'dec' => 'december',
//            'january' => 'jan',
//            'february' => 'feb',
//            'march' => 'mar',
//            'april' => 'apr',
//            'may' => 'may',
//            'june' => 'jun',
//            'july' => 'jul',
//            'august' => 'aug',
//            'september' => 'sep',
//            'october' => 'oct',
//            'november' => 'nov',
//            'december' => 'dec',
//];


$months = [
            'jan' => 01,
            'feb' => 02,
            'mar' => 03,
            'apr' => 04,
            'may' => 05,
            'jun' => 06,
            'jul' => 07,
            'aug' => 08,
            'sep' => 09,
            'oct' => 10,
            'nov' => 11,
            'dec' => 12,
            'january' => 01,
            'february' => 02,
            'march' => 03,
            'april' => 04,
            'may' => 05,
            'june' => 06,
            'july' => 07,
            'august' => 08,
            'september' => 09,
            'october' => 10,
            'november' => 11,
            'december' => 12,
];

$days = [
            'mon' => 'monday',
            'tue' => 'tuesday',
            'wed' => 'wednesday',
            'thu' => 'thursday',
            'fri' => 'friday',
            'sat' => 'saturday',
            'sun' => 'sunday',
            'monday' => 'mon',
            'tuesday' => 'tue',
            'wednesday' => 'wed',
            'thursday' => 'thu',
            'friday' => 'fri',
            'saturday' => 'sat',
            'sunday' => 'sun',
];

?>