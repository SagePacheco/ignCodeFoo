<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>IGN Date and Time</title>
</head>

<body>
<form method="get" action="regExp.php">
<input name="dt" type="text" placeholder="Date and Time">
<input type="submit">
</form>
<pre>
<?php
if(isset($_GET['dt'])){
	$userInput = $_GET['dt'];
	$time = new ignTime($userInput);
//	echo $time->getISO();
} else {
	$timeExamples = [
	'3/20/2016',
	'4:05:07 PM',
	'Sunday, March 20, 2016',
	'Sunday, March 20, 2016 4:05 PM',
	'Sunday, March 20, 2016 4:05:07 PM',
	'Sunday 20th of March 2016 04:05:07 PM',
	'Sunday, MAR 20, 2016',
	'3/20/2016 4:05:07 PM',
	'March 20, 2016',
	'March 20',
	'March, 2016',
	'Sun, 20 Mar 2016 16:05:07 GMT',
	'Sun, 20 Mar 2016 16:05:07 -0800',
	'20160320 16:05:07',
	'20160320',
	'2016.03.20',
	'20/03/2016',
	'20 March 2016',
	'2016-20-03T16:05:07-08:00'
];
//	foreach($timeExamples as $key => $value){
//		$exampleCollection[$key] = new ignTime($value);
//		$exampleCollection[$key]->getISO();
//	}
}

class ignTime{
	
	var $year;
	var $month;
	var $day;
	var $hour;
	var $minute;
	var $second;
	var $gmtOffset;
	var $amOrPm;
	var $nameDay;
	var $iso;
	
	public function __construct($userInput){
		$this->setISO($userInput);	
	}
	
	private function setISO($userInput){
		
		// Initialize Regular Expressions
		$exNameDay='(monday|tuesday|wednesday|thursday|friday|saturday|sunday|tues|thur|thurs|sun|mon|tue|wed|thu|fri|sat)';
		$exMonth='(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|sept|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)';
		$exDay='(?:((?:[0-2]?\\d{1})|(?:[3][01]{1}))(?![\\d]))';
		$exYear='(?:((?:[1]{1}\\d{1}\\d{1}\\d{1})|(?:[2]{1}\\d{3}))(?![\\d]))';
		$exHMS12 = '(?:\b((?:[0-1][0-2])|(?:[0-9])):([0-5][0-9]):?([0-5][0-9])?\s?(am|pm)?)';
		$exHMS24 = '(?:((?:[0-1][0-9])|(?:[2][0-3])):([0-5][0-9]):?([0-5][0-9])(?! pm))';
		$exMDY = '(?:([0]?[1-9]|[1][012])[-:\\/.]((?:[0-2]?\\d{1})|(?:[3][01]{1}))[-:\\/.]((?:[1]{1}\\d{1}\\d{1}\\d{1})|(?:[2]{1}\\d{3})))(?![\\d])';
		$exYMDInt = '(?:((?:[1]{1}\d{1}\d{1}\d{1})|(?:[2]{1}\d{3}))([0]?[1-9]|[1][012])((?:[0-2]?\d{1})|(?:[3][01]{1}))(?![\d]))';

		print '/' . $exNameDay . '\s' . $exDay . '(?:[snrt][tdh])\sof\s'  . $exMonth . '\s' . $exYear . '\s' . $exHMS12 . '/';
		
		// Standardize user input
		$userInput = strtolower(trim($userInput));
		switch($userInput){
			
			//	3/20/2016
			//	3/20/2016 4:05 PM
			//	3/20/2016 4:05:07 PM
			case (preg_match_all('/'. $exMDY . '\s?' . $exHMS12 . '?' . '/', $userInput, $matches) ? true : false):	
				$message[0] = "Case Run is 1";
				$message[1] = $matches;
				var_dump($message);
				$this->month = $matches[2][0];
				$this->day = $matches[3][0];
				$this->year = $matches[4][0];
				break;
								
			// Sunday, March 20, 2016
			// Sunday, March 20, 2016 4:05 PM
			// Sunday, March 20, 2016 4:05:07 PM
			// Sunday, MAR 20, 2016
			case (preg_match_all('/' . $exNameDay . ',\s' . $exMonth . '\s' . $exDay . ',\s' . $exYear . '\s?' . $exHMS12 . '?' . '/', $userInput, $matches) ? true : false):
				$message[0] = "Case Run is 2";
				$message[1] = $matches;
				var_dump($message);
				$this->nameDay = $matches[1][0];
				$this->month = $matches[2][0];
				$this->day = $matches[3][0];
				$this->year = $matches[4][0];
				break;
			
			//	20 March 2016
			case (preg_match_all('/' . $exDay . '\s' . $exMonth . '\s' . $exYear . '/', $userInput, $matches) ? true : false):
				$message[0] = "Case Run is 3";
				$message[1] = $matches;
				var_dump($message);
				break;
				
			// 4:05:07 PM
			case (preg_match_all('/' . $exHMS12 . '/', $userInput, $matches) ? true : false):	
				$message[0] = "Case Run is 4";
				$message[1] = $matches;
				var_dump($message);
				$this->hour = $matches[1][0];
				$this->minute = $matches[2][0];
				$this->second = $matches[3][0];
				$this->amOrPm = $matches[4][0];
				break;

			//	March 20, 2016
			//	March 20
			//	March, 2016
			case (preg_match_all('/' . $exMonth . '[,\s]?\s?' . $exDay . '?[,\s]?\s?' . $exYear . '?' . '/', $userInput, $matches) ? true : false):
				$message[0] = "Case Run is 5";
				$message[1] = $matches;
				var_dump($message);
				break;
				


			//	20160320 16:05:07 
			//	20160320
			case (preg_match_all('/' . $exYMDInt . '\s' . $exHMS24 . '?' . '/', $userInput, $matches) ? true : false):
				$message[0] = "Case Run is 6";
				$message[1] = $matches;
				var_dump($message);
				break;


			//	Sunday 20th of March 2016 04:05:07 PM
			case (preg_match_all('/' . $exNameDay . '\s' . $exDay . '(?:[snrt][tdh])\sof\s'  . $exMonth . '\s' . $exYear . '\s' . $exHMS12 . '/', $userInput, $matches) ? true : false):
				$message[0] = "Case Run is 7";
				$message[1] = $matches;
				var_dump($message);
				break;
//				
//			//	Sun, 20 Mar 2016 16:05:07 GMT
//			//	Sun, 20 Mar 2016 16:05:07 -0800
//			case (preg_match_all('//', $userInput, $matches) ? true : false):
//				$message[0] = "Case Run is 8";
//				$message[1] = $matches;
//				var_dump($message);
//				break;
//				
//			//	2016.03.20
//			case (preg_match_all('//', $userInput, $matches) ? true : false):
//				$message[0] = "Case Run is 9";
//				$message[1] = $matches;
//				var_dump($message);
//				break;
//				
//			//	20/03/2016
//			case (preg_match_all('//', $userInput, $matches) ? true : false):
//				$message[0] = "Case Run is 10";
//				$message[1] = $matches;
//				var_dump($message);
//				break;
//				
//			//	2016-20-03T16:05:07-08:00
//			case (preg_match_all('//', $userInput, $matches) ? true : false):
//				$message[0] = "Case Run is 11";
//				$message[1] = $matches;
//				var_dump($message);
//				break;
//
			default:
				print "The input didn't seem to catch a pattern";
				break;

		}
	}
	
//	public function getISO(){
//		print "The Year is: $this->year \n";
//		print "The Month is: $this->month \n";
//		print "The Day is: $this->day \n";
//		print "The time of day is: $this->amOrPm \n\n";
//		return '';
//	}
}
?>
</pre>
</body>
</html>