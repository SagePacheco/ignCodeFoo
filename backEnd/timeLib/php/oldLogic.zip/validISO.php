<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>IGN Date and Time</title>
</head>

<body>
<form method="get" action="validISO.php">
<input name="dt" type="text" placeholder="Date and Time">
<input type="submit">
</form>
<pre>
<?php
if(isset($_GET['dt'])){
	$userInput = $_GET['dt'];
	$time = new ignTime($userInput);
	echo $time->getISO();
} else {
	$timeExamples = [
	'3/20/2016',
	'4:05:07 PM',
	'Sunday, March 20, 2016',
	'Sunday, March 20, 2016 4:05 PM',
	'Sunday, March 20, 2016 4:05:07 PM',
	'Sunday 20th of March 2016 04:05:07 PM',
	'Sunday, MAR 20, 2016',
	'3/20/2016 4:05:07 PM',
	'March 20, 2016',
	'March 20',
	'March, 2016',
	'Sun, 20 Mar 2016 16:05:07 GMT',
	'Sun, 20 Mar 2016 16:05:07 -0800',
	'20160320 16:05:07',
	'20160320',
	'2016.03.20',
	'20/03/2016',
	'20 March 2016',
	'2016-20-03T16:05:07-08:00'
];
	foreach($timeExamples as $key => $value){
		$exampleCollection[$key] = new ignTime($value);
		$exampleCollection[$key]->getISO();
	}
}

class ignTime{
	
	var $year;
	var $month;
	var $day;
	var $hour;
	var $minute;
	var $second;
	var $gmtOffset;
	var $amOrPm;
	var $iso;
	var $months = [
				'january' => 01,
				'february' => 02,
				'march' => 03,
				'april' => 04,
				'may' => 05,
				'june' => 06,
				'july' => 07,
				'august' => 08,
				'september' => 09,
				'october' => 10,
				'november' => 11,
				'december' => 12,
				'jan' => 01,
				'feb' => 02,
				'mar' => 03,
				'apr' => 04,
				'may' => 05,
				'jun' => 06,
				'jul' => 07,
				'aug' => 08,
				'sep' => 09,
				'oct' => 10,
				'nov' => 11,
				'dec' => 12,
	];
	var $days = [
				'mon' => 'monday',
				'tue' => 'tuesday',
				'wed' => 'wednesday',
				'thu' => 'thursday',
				'fri' => 'friday',
				'sat' => 'saturday',
				'sun' => 'sunday',
				'monday' => 'mon',
				'tuesday' => 'tue',
				'wednesday' => 'wed',
				'thursday' => 'thu',
				'friday' => 'fri',
				'saturday' => 'sat',
				'sunday' => 'sun',
	];
	
	
	public function __construct($userInput){
		$this->setISO($userInput);	
	}
	
	private function setISO($userInput){
	
	// Remove Whitespace
	$userInput = trim($userInput);
	
	// Switch to Lowercase
	$userInput = strtolower($userInput);
	
	// Strip out commas
	$userInput = str_replace(',', '', $userInput);
	
	// Strip out other misc
	$userInput = str_replace('th', '', $userInput);
	$userInput = str_replace('st', '', $userInput);
	$userInput = str_replace('of', '', $userInput);
	
	// Strip out named days
	foreach($this->days as $value){
		$userInput = str_replace($value, '', $userInput, $replaced);
		if($replaced >0){
			break;	
		}
	}
	
	// Strip out named months
	foreach($this->months as $key => $value){
		$userInput = str_replace($key, '', $userInput, $replaced);
		if($replaced > 0){
			$this->month = $value;
			break;
		}
	}
	
	// Strip out integer year
	if(preg_match_all('/(?!\/)[12]\d\d\d/', $userInput, $match)){
		$this->year = $match[0][0];
		$userInput = str_replace($this->year, '', $userInput);
	}
	
	// Strip out integer month
	//
	//
	//
	
	// Strip out integer day
	//
	//
	//
	
	// Find AM or PM
	if(preg_match_all('/am|pm/', $userInput, $match)){
		$this->amOrPm = $match[0][0];
		$userInput = str_replace($this->amOrPm, '', $userInput);
	}
	
	// Strip out Time
	if(preg_match_all('/((?:(?:[0-1][0-9])|(?:[2][0-3])|(?:[0-9])):(?:[0-5][0-9])(?::[0-5][0-9])?(?:\\s?)?)/', $userInput, $match)){
		print "Extracted Time is: " . $match[0][0] . "\n";
		$userInput = str_replace($match[0][0], '', $userInput);
		
		// Create Subroutine that grabs hours, minutes, and seconds
	}
	
	// Strip out GMT offset
	if(preg_match_all('/(-\d?\d?\d?\d\d:?\d\d)/', $userInput, $match)){
		$userInput = str_replace($match[0][0], '', $userInput);
		
		// Create Subroutine that grabs hours, minutes, and seconds
	}
	
	
	$this->iso = $userInput;
	print "What we didn't get: $userInput \n";
	
	}
	
	public function getISO(){
		print "The Year is: $this->year \n";
		print "The Month is: $this->month \n";
		print "The Day is: $this->day \n";
		print "The time of day is: $this->amOrPm \n\n";
		return '';
	}
}
?>
</pre>
</body>
</html>